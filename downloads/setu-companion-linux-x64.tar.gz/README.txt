Setu Companion (Linux 64-bit)
====================================================
Requirements:
For native input execution, install xdotool:
  sudo apt install xdotool    (Debian/Ubuntu)
  sudo dnf install xdotool    (Fedora/RHEL)
  sudo pacman -S xdotool      (Arch)

How to Run:
1. Open Terminal in this folder.
2. Run: chmod +x run-companion.sh && ./run-companion.sh

Updating Setu Companion:
Extract the new bundle into this folder and overwrite existing files.
Your existing config.json is never overwritten.