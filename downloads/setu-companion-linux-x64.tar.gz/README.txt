Setu Companion (Linux 64-bit)
====================================================
How to Run:
1. Open Terminal in this folder.
2. Run: chmod +x run-companion.sh && ./run-companion.sh
