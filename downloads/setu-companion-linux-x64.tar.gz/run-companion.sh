#!/bin/bash
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" >/dev/null 2>&1 && pwd )"
cd "$DIR"
if [ -f "./setu-companion" ]; then
    chmod +x ./setu-companion
    ./setu-companion "$@"
else
    node setu-companion.js "$@"
fi
