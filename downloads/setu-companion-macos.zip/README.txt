Setu Companion (macOS)
====================================================
Requirements:
Grant Accessibility permission in System Settings -> Privacy & Security -> Accessibility.

How to Run:
1. Open Terminal in this folder.
2. Run: ./run-companion.sh

Updating Setu Companion:
Extract the new bundle into this folder and overwrite existing files.
Your existing config.json is never overwritten.