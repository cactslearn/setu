Setu Companion (macOS)
====================================================
Requirements:
Grant Accessibility permission in System Settings -> Privacy & Security -> Accessibility.

How to Run:
1. Open Terminal in this folder.
2. Run: ./run-companion.sh
