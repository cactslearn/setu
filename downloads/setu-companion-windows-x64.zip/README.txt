Setu Companion (Windows 64-bit)
====================================================
This background application allows remote participants to control your screen
when you grant permission during a Setu meeting.

How to Run:
1. Double-click run-companion.bat (or setu-companion.exe if compiled).
2. Keep this window open while sharing your screen.
3. Configure your Port and Security Passkey in config.json to match Setu Settings.

Security:
- Listens exclusively on 127.0.0.1 (localhost).
- Requires your security passkey to execute any commands.
- Host supremacy: If you touch your physical mouse, remote commands are immediately paused.

Updating Setu Companion:
When an update is released, simply extract the new files into this folder and replace them.
Your existing config.json (which contains your private passkey and port) is never overwritten.
