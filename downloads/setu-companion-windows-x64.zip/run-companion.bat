@echo off
title Setu Companion Daemon
cd /d "%~dp0"
if exist "setu-companion.exe" (
    start "" "setu-companion.exe" %*
) else (
    node "setu-companion.js" %*
)
